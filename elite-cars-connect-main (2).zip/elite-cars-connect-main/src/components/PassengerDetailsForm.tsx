
import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';
import { Ride } from '@/data/rides';
import { Users, X, CreditCard, Phone, Mail, User, CheckCircle } from 'lucide-react';

interface PassengerDetailsFormProps {
  ride: Ride;
  onComplete: (passengerDetails: PassengerDetail[]) => void;
  onCancel: () => void;
}

export interface PassengerDetail {
  name: string;
  aadhaarNumber: string;
  phone: string;
  email: string;
}

const PassengerDetailsForm = ({ ride, onComplete, onCancel }: PassengerDetailsFormProps) => {
  const [numberOfSeats, setNumberOfSeats] = useState(1);
  const [passengerDetails, setPassengerDetails] = useState<PassengerDetail[]>([
    { name: '', aadhaarNumber: '', phone: '', email: '' }
  ]);
  const [errors, setErrors] = useState<{ [key: string]: string }>({});
  const { toast } = useToast();

  const handleSeatChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const seats = parseInt(e.target.value);
    setNumberOfSeats(seats);
    
    // Adjust the passenger details array based on seat count
    if (seats > passengerDetails.length) {
      // Add more passenger forms
      const newPassengers = Array(seats - passengerDetails.length).fill(null).map(() => (
        { name: '', aadhaarNumber: '', phone: '', email: '' }
      ));
      setPassengerDetails([...passengerDetails, ...newPassengers]);
    } else if (seats < passengerDetails.length) {
      // Remove excess passenger forms
      setPassengerDetails(passengerDetails.slice(0, seats));
    }
  };

  const updatePassengerDetail = (index: number, field: keyof PassengerDetail, value: string) => {
    const newDetails = [...passengerDetails];
    newDetails[index] = { ...newDetails[index], [field]: value };
    setPassengerDetails(newDetails);
    
    // Clear error for this field if it exists
    if (errors[`${index}-${field}`]) {
      const newErrors = { ...errors };
      delete newErrors[`${index}-${field}`];
      setErrors(newErrors);
    }
  };

  const validateAadhaar = (aadhaar: string): boolean => {
    // Basic validation: 12 digits
    return /^\d{12}$/.test(aadhaar);
  };

  const validatePhone = (phone: string): boolean => {
    // Basic validation: 10 digits
    return /^\d{10}$/.test(phone);
  };

  const validateEmail = (email: string): boolean => {
    // Basic email format validation
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
  };

  const validateForm = (): boolean => {
    const newErrors: { [key: string]: string } = {};
    let isValid = true;

    passengerDetails.forEach((passenger, index) => {
      if (!passenger.name.trim()) {
        newErrors[`${index}-name`] = "Name is required";
        isValid = false;
      }

      if (!validateAadhaar(passenger.aadhaarNumber)) {
        newErrors[`${index}-aadhaarNumber`] = "Valid 12-digit Aadhaar number is required";
        isValid = false;
      }

      if (!validatePhone(passenger.phone)) {
        newErrors[`${index}-phone`] = "Valid 10-digit phone number is required";
        isValid = false;
      }

      if (!validateEmail(passenger.email)) {
        newErrors[`${index}-email`] = "Valid email address is required";
        isValid = false;
      }
    });

    setErrors(newErrors);
    return isValid;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (validateForm()) {
      // Check if enough seats are available
      if (numberOfSeats > ride.seatsAvailable) {
        toast({
          title: "Not enough seats",
          description: `Only ${ride.seatsAvailable} seats are available on this ride.`,
          variant: "destructive"
        });
        return;
      }
      
      toast({
        title: "Passenger details confirmed",
        description: `Details for ${numberOfSeats} passenger(s) have been saved.`,
      });
      
      onComplete(passengerDetails);
    }
  };

  return (
    <div className="bg-white rounded-lg p-6">
      <div className="flex justify-between items-center mb-6">
        <h3 className="text-xl font-bold text-gray-800 flex items-center">
          <Users className="mr-2 text-primary" size={20} />
          Passenger Details
        </h3>
        <Button variant="ghost" size="icon" onClick={onCancel} className="rounded-full">
          <X size={20} />
        </Button>
      </div>

      <form onSubmit={handleSubmit}>
        <div className="mb-6">
          <Label htmlFor="seatCount" className="text-gray-700">Number of Seats</Label>
          <div className="flex items-center mt-1">
            <select
              id="seatCount"
              value={numberOfSeats}
              onChange={handleSeatChange}
              className="border rounded-md py-2 px-3 w-full focus:outline-none focus:ring-2 focus:ring-primary"
            >
              {Array.from({ length: Math.min(ride.seatsAvailable, 6) }, (_, i) => i + 1).map(num => (
                <option key={num} value={num}>{num} {num === 1 ? 'passenger' : 'passengers'}</option>
              ))}
            </select>
          </div>
          <p className="text-sm text-gray-500 mt-1">
            {ride.seatsAvailable} seats available on this ride
          </p>
        </div>

        <div className="space-y-8">
          {passengerDetails.map((passenger, index) => (
            <div key={index} className="border rounded-lg p-4 bg-gray-50">
              <div className="flex items-center mb-3">
                <User className="text-primary mr-2" size={18} />
                <h4 className="font-medium">Passenger {index + 1}</h4>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor={`name-${index}`} className="text-gray-700">Full Name</Label>
                  <Input
                    id={`name-${index}`}
                    value={passenger.name}
                    onChange={e => updatePassengerDetail(index, 'name', e.target.value)}
                    placeholder="Enter full name as per Aadhaar"
                    className="mt-1"
                  />
                  {errors[`${index}-name`] && (
                    <p className="text-destructive text-sm mt-1">{errors[`${index}-name`]}</p>
                  )}
                </div>
                
                <div>
                  <Label htmlFor={`aadhaar-${index}`} className="text-gray-700 flex items-center">
                    Aadhaar Number
                    <span className="ml-1 text-xs bg-blue-100 text-blue-700 px-2 py-0.5 rounded">Verification Required</span>
                  </Label>
                  <Input
                    id={`aadhaar-${index}`}
                    value={passenger.aadhaarNumber}
                    onChange={e => updatePassengerDetail(index, 'aadhaarNumber', e.target.value)}
                    placeholder="12-digit Aadhaar number"
                    maxLength={12}
                    className="mt-1"
                  />
                  {errors[`${index}-aadhaarNumber`] && (
                    <p className="text-destructive text-sm mt-1">{errors[`${index}-aadhaarNumber`]}</p>
                  )}
                </div>
                
                <div>
                  <Label htmlFor={`phone-${index}`} className="text-gray-700">Phone Number</Label>
                  <Input
                    id={`phone-${index}`}
                    value={passenger.phone}
                    onChange={e => updatePassengerDetail(index, 'phone', e.target.value)}
                    placeholder="10-digit mobile number"
                    maxLength={10}
                    className="mt-1"
                  />
                  {errors[`${index}-phone`] && (
                    <p className="text-destructive text-sm mt-1">{errors[`${index}-phone`]}</p>
                  )}
                </div>
                
                <div>
                  <Label htmlFor={`email-${index}`} className="text-gray-700">Email Address</Label>
                  <Input
                    id={`email-${index}`}
                    value={passenger.email}
                    onChange={e => updatePassengerDetail(index, 'email', e.target.value)}
                    placeholder="For e-ticket and updates"
                    type="email"
                    className="mt-1"
                  />
                  {errors[`${index}-email`] && (
                    <p className="text-destructive text-sm mt-1">{errors[`${index}-email`]}</p>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="border-t border-gray-200 mt-6 pt-6 flex justify-between">
          <Button variant="outline" onClick={onCancel}>
            Back
          </Button>
          <Button type="submit" className="flex items-center">
            <CheckCircle className="mr-2" size={18} />
            Continue to Payment
          </Button>
        </div>
      </form>
    </div>
  );
};

export default PassengerDetailsForm;
