import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Ride } from '@/data/rides';
import { 
  Car, Calendar, Clock, MapPin, User, Phone, MessageSquare, 
  Shield, Star, IndianRupee, Users, Tag, Percent, Info, X
} from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import LiveTrackingDemo from './LiveTrackingDemo';
import PassengerDetailsForm, { PassengerDetail } from './PassengerDetailsForm';
import PaymentPage from './payment/PaymentPage';

interface RideDetailsProps {
  ride: Ride;
  onClose: () => void;
  onBookingComplete?: (ride: Ride) => void;
}

const RideDetails = ({ ride, onClose, onBookingComplete }: RideDetailsProps) => {
  const [step, setStep] = useState<'details' | 'passenger-details' | 'payment' | 'tracking'>('details');
  const [passengerDetails, setPassengerDetails] = useState<PassengerDetail[]>([]);
  
  const handlePassengerDetailsComplete = (details: PassengerDetail[]) => {
    setPassengerDetails(details);
    setStep('payment');
  };
  
  const handlePaymentComplete = () => {
    setStep('tracking');
    
    // Call onBookingComplete if provided
    if (onBookingComplete) {
      onBookingComplete(ride);
    }
  };
  
  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4 overflow-y-auto animate-fade-in">
      <div className="max-w-3xl w-full mx-auto">
        {step === 'details' && (
          <Card className="shadow-xl border-none">
            <CardHeader className="bg-primary/5 border-b border-primary/10">
              <div className="flex justify-between items-start">
                <div>
                  <CardTitle className="text-xl text-slate-800 flex items-center">
                    <Car className="mr-2 text-primary" size={20} />
                    Ride Details
                  </CardTitle>
                  <CardDescription>
                    {ride.from} to {ride.to} on {ride.date}
                  </CardDescription>
                </div>
                <Badge variant={ride.verified ? "default" : "outline"} className="ml-2">
                  {ride.verified ? (
                    <Shield className="h-3 w-3 mr-1 text-primary-foreground" />
                  ) : null}
                  {ride.verified ? 'Verified Ride' : 'Standard Ride'}
                </Badge>
              </div>
            </CardHeader>
            
            <CardContent className="py-6">
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <h3 className="font-medium text-primary mb-4 flex items-center">
                    <MapPin className="mr-2 h-4 w-4" />
                    Route Information
                  </h3>
                  
                  {/* Route Info */}
                  <div className="mb-5 space-y-4">
                    <div className="relative pl-7 pb-6">
                      <div className="absolute left-2 top-1 h-full w-0.5 bg-primary/20"></div>
                      <div className="absolute left-0 top-0 h-4 w-4 rounded-full bg-primary flex items-center justify-center">
                        <div className="h-2 w-2 rounded-full bg-white"></div>
                      </div>
                      <div>
                        <p className="font-medium text-gray-900">{ride.from}</p>
                        <p className="text-sm text-muted-foreground">{ride.fromDetail}</p>
                        <div className="text-sm text-muted-foreground mt-1">
                          <Clock className="inline h-3.5 w-3.5 mr-1" />
                          {ride.departureTime}
                        </div>
                      </div>
                    </div>
                    
                    <div className="relative pl-7">
                      <div className="absolute left-0 top-0 h-4 w-4 rounded-full bg-accent flex items-center justify-center">
                        <div className="h-2 w-2 rounded-full bg-white"></div>
                      </div>
                      <div>
                        <p className="font-medium text-gray-900">{ride.to}</p>
                        <p className="text-sm text-muted-foreground">{ride.toDetail}</p>
                        <div className="text-sm text-muted-foreground mt-1">
                          <Clock className="inline h-3.5 w-3.5 mr-1" />
                          {ride.arrivalTime}
                        </div>
                      </div>
                    </div>
                  </div>
                  
                  {/* Date & Time */}
                  <div className="mb-5">
                    <h4 className="text-sm font-medium text-gray-700 mb-2">Date & Time</h4>
                    <div className="flex items-center space-x-4">
                      <div className="flex items-center text-slate-700">
                        <Calendar className="h-4 w-4 mr-1 text-primary" />
                        <span>{ride.date}</span>
                      </div>
                      <div className="flex items-center text-slate-700">
                        <Clock className="h-4 w-4 mr-1 text-primary" />
                        <span>{ride.departureTime}</span>
                      </div>
                    </div>
                  </div>
                  
                  {/* Price & Seat Info */}
                  <div>
                    <h4 className="text-sm font-medium text-gray-700 mb-2">Price & Seats</h4>
                    <div className="flex items-center justify-between">
                      <div className="text-xl font-bold text-slate-800 flex items-center">
                        <IndianRupee className="h-5 w-5 mr-1 text-primary" />
                        {ride.price}
                      </div>
                      <div className="flex items-center text-slate-700">
                        <Users className="h-4 w-4 mr-1 text-primary" />
                        <span>{ride.seatsAvailable} seats available</span>
                      </div>
                    </div>
                  </div>
                </div>
                
                <div className="border-t md:border-t-0 md:border-l border-gray-200 pt-4 md:pt-0 md:pl-6">
                  <h3 className="font-medium text-primary mb-4 flex items-center">
                    <User className="mr-2 h-4 w-4" />
                    Driver & Vehicle Details
                  </h3>
                  
                  {/* Driver Details */}
                  <div className="mb-5">
                    <div className="flex items-center">
                      <div className="h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center mr-3">
                        <User className="h-6 w-6 text-primary" />
                      </div>
                      <div>
                        <p className="font-medium">{ride.driverName}</p>
                        <div className="flex items-center text-sm">
                          <Star className="h-3.5 w-3.5 text-yellow-500 mr-1" fill="#FACC15" />
                          <span>{ride.driverRating} rating</span>
                        </div>
                      </div>
                    </div>
                    
                    <div className="flex mt-3 space-x-2">
                      <Button variant="outline" size="sm" className="text-xs h-8">
                        <Phone className="h-3 w-3 mr-1" />
                        Call
                      </Button>
                      <Button variant="outline" size="sm" className="text-xs h-8">
                        <MessageSquare className="h-3 w-3 mr-1" />
                        Message
                      </Button>
                    </div>
                  </div>
                  
                  {/* Vehicle Details */}
                  <div className="mb-5">
                    <h4 className="text-sm font-medium text-gray-700 mb-2">Vehicle Details</h4>
                    <div className="p-3 rounded-lg bg-gray-50">
                      <div className="flex justify-between text-sm mb-1">
                        <span className="text-gray-600">Vehicle Model:</span>
                        <span className="font-medium">{ride.carModel}</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-gray-600">Luggage Space:</span>
                        <span className="font-medium">Medium (2 suitcases)</span>
                      </div>
                    </div>
                  </div>
                  
                  {/* Amenities */}
                  <div>
                    <h4 className="text-sm font-medium text-gray-700 mb-2">Ride Amenities</h4>
                    <div className="flex flex-wrap gap-2">
                      {ride.amenities.map((amenity, index) => (
                        <Badge key={index} variant="outline" className="flex items-center">
                          <Tag className="mr-1 h-3 w-3" />
                          {amenity}
                        </Badge>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
              
              {/* Safety Information */}
              <div className="mt-6 p-3 bg-blue-50 rounded-lg border border-blue-100">
                <div className="flex items-center mb-1">
                  <Shield className="h-4 w-4 text-blue-600 mr-2" />
                  <h4 className="font-medium text-blue-800 text-sm">Safety Information</h4>
                </div>
                <p className="text-blue-700 text-xs">
                  This ride is {ride.verified ? 'verified' : 'not verified'} by EliteCars. 
                  {ride.verified 
                    ? ' We have confirmed the driver\'s identity, vehicle details, and driving license.' 
                    : ' We recommend checking the driver\'s ID before starting your journey.'}
                </p>
              </div>
            </CardContent>
            <CardFooter className="bg-gray-50 border-t border-gray-200 flex-col gap-4 sm:flex-row">
              <Button variant="outline" onClick={onClose} className="flex-1">
                Back
              </Button>
              <Button 
                className="flex-1"
                onClick={() => setStep('passenger-details')}
              >
                Book Now
                <IndianRupee className="ml-2 h-4 w-4" />
              </Button>
            </CardFooter>
          </Card>
        )}
        
        {step === 'passenger-details' && (
          <Card className="shadow-xl border-none">
            <CardContent className="p-0">
              <PassengerDetailsForm
                ride={ride}
                onComplete={handlePassengerDetailsComplete}
                onCancel={() => setStep('details')}
              />
            </CardContent>
          </Card>
        )}
        
        {step === 'payment' && (
          <Card className="shadow-xl border-none">
            <CardContent className="p-0">
              <PaymentPage 
                ride={ride}
                passengerDetails={passengerDetails}
                onPaymentComplete={handlePaymentComplete}
                onCancel={() => setStep('passenger-details')}
              />
            </CardContent>
          </Card>
        )}
        
        {step === 'tracking' && (
          <div>
            <Card className="shadow-xl border-none mb-4">
              <CardHeader>
                <CardTitle className="text-lg">
                  Booking Confirmed - Track Your Ride
                </CardTitle>
                <CardDescription>
                  Your ride from {ride.from} to {ride.to} is confirmed for {ride.date}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <LiveTrackingDemo />
                
                <div className="mt-6 p-4 bg-green-50 rounded-lg border border-green-100">
                  <div className="flex items-center mb-2">
                    <Info className="text-green-600 mr-2" size={18} />
                    <h4 className="font-medium text-green-800">How It Works</h4>
                  </div>
                  <p className="text-green-700 text-sm">
                    On the day of your ride, you'll be able to track your driver in real-time. 
                    You can share your live location with trusted contacts for enhanced safety.
                  </p>
                </div>
              </CardContent>
              <CardFooter className="border-t border-gray-200 p-4">
                <Button onClick={onClose} className="w-full">
                  Back to Dashboard
                </Button>
              </CardFooter>
            </Card>
          </div>
        )}
      </div>
    </div>
  );
};

export default RideDetails;
