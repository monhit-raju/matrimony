
import React from 'react';
import { 
  Car, Clock, Calendar, Users, MapPin, 
  Star, ArrowRight, IndianRupee, Shield, 
} from 'lucide-react';
import { Card, CardContent, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Ride } from '@/data/rides';

interface RideCardProps {
  ride: Ride;
  userRole: string;
  onAction: (action: 'book' | 'offer' | 'details') => void;
}

const RideCard: React.FC<RideCardProps> = ({ ride, userRole, onAction }) => {
  const isPassenger = userRole === 'passenger';
  
  return (
    <Card className="overflow-hidden border-none shadow-md hover:shadow-xl transition-all duration-300 bg-white animate-fade-in">
      <div className="bg-primary/5 p-3 flex justify-between items-center border-b border-primary/10">
        <div className="flex items-center">
          <Badge variant={ride.verified ? "default" : "outline"} className="mr-2">
            {ride.verified ? (
              <Shield className="h-3 w-3 mr-1 text-primary-foreground" />
            ) : null}
            {ride.verified ? 'Verified' : 'Standard'}
          </Badge>
          <div className="flex items-center text-sm text-muted-foreground">
            <Calendar className="h-3.5 w-3.5 mr-1" />
            <span>{ride.date}</span>
          </div>
        </div>
        <div className="flex items-center">
          <Star className="h-4 w-4 text-yellow-500 mr-1" fill="#FACC15" />
          <span className="font-medium">{ride.rating}</span>
        </div>
      </div>
      
      <CardContent className="p-4">
        <div className="mb-4">
          <div className="relative pl-7 pb-6">
            <div className="absolute left-2 top-1 h-full w-0.5 bg-primary/20"></div>
            <div className="absolute left-0 top-0 h-4 w-4 rounded-full bg-primary flex items-center justify-center">
              <div className="h-2 w-2 rounded-full bg-white"></div>
            </div>
            <div className="flex justify-between">
              <div>
                <p className="font-medium text-gray-900">{ride.from}</p>
                <p className="text-sm text-muted-foreground">{ride.fromDetail}</p>
              </div>
              <div className="text-sm text-muted-foreground">
                <Clock className="inline h-3.5 w-3.5 mr-1" />
                {ride.departureTime}
              </div>
            </div>
          </div>
          
          <div className="relative pl-7">
            <div className="absolute left-0 top-0 h-4 w-4 rounded-full bg-accent flex items-center justify-center">
              <div className="h-2 w-2 rounded-full bg-white"></div>
            </div>
            <div className="flex justify-between">
              <div>
                <p className="font-medium text-gray-900">{ride.to}</p>
                <p className="text-sm text-muted-foreground">{ride.toDetail}</p>
              </div>
              <div className="text-sm text-muted-foreground">
                <Clock className="inline h-3.5 w-3.5 mr-1" />
                {ride.arrivalTime}
              </div>
            </div>
          </div>
        </div>

        <div className="flex justify-between items-center mt-4 pt-3 border-t border-gray-100">
          <div className="flex items-center">
            <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center mr-3">
              <Car className="h-5 w-5 text-primary" />
            </div>
            <div>
              <p className="font-medium">{ride.driverName}</p>
              <p className="text-xs text-muted-foreground">{ride.carModel}</p>
            </div>
          </div>
          
          <div className="text-right">
            <div className="flex items-center justify-end">
              <IndianRupee className="h-4 w-4 text-gray-700" />
              <span className="font-bold text-lg text-gray-900">{ride.price}</span>
            </div>
            <div className="flex items-center text-xs text-muted-foreground">
              <Users className="h-3.5 w-3.5 mr-1" />
              <span>{ride.seatsAvailable} seats available</span>
            </div>
          </div>
        </div>
      </CardContent>
      
      <CardFooter className="px-4 py-3 bg-gray-50 gap-3">
        <Button 
          variant="outline" 
          size="sm" 
          className="w-1/2"
          onClick={() => onAction('details')}
        >
          Details
        </Button>
        <Button 
          size="sm" 
          className="w-1/2"
          onClick={() => onAction(isPassenger ? 'book' : 'offer')}
        >
          {isPassenger ? 'Book Ride' : 'Edit Ride'}
        </Button>
      </CardFooter>
    </Card>
  );
};

export default RideCard;
